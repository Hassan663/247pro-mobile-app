// export { WP, HP } from './styling/responsive';
// export { colors } from './colors';
export {
    paginationLimit,
    DEFAULT_LANGUAGE,
    version,
    platform,
    systemVersion,
    deviceUId,
    deviceType,
    hasNotch
} from './constants';
export { languageData } from './languageData'; 