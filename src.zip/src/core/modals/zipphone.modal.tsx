export interface ZipAndPhone {
  postalCode: string;
  phone: string;
  phoneCountryId: number;
}
