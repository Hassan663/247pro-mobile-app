export const INDUSTRIES = ["Construction", "Food", "Oil", "Electronics"]
