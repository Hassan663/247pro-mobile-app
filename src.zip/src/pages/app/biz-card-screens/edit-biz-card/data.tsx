import { t } from "i18next"

export const SOCIALINPUTSDATA = [
    { name: "Facebook", icon: require('../../../../assets/app-images/facebook.png') },
    { name: "Instagram", icon: require('../../../../assets/app-images/instagram.png') },
    { name: "Linked In", icon: require('../../../../assets/app-images/linkedin.png') },
    { name: "Twitter", icon: require('../../../../assets/app-images/twitter.png') },
]

export const CONTACTINFOINPUTS = [t('EMail'), t('Website'), t('StreetAddress')]