export const REQUESTCONTACTLIST = [
    { name: "George Lee", type: 'General Contractor', photoURL: require('../../../../assets/app-images/userImg.png') },
]