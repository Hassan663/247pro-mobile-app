import { t } from "i18next";

export const ACCOUNTSETTINGDATA = [t(`AccountInformation`), t('ChangePassword'), t(`Subscription`), t(`CountryAndLanguage`)]