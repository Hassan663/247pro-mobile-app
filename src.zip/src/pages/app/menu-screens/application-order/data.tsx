import { t } from "i18next";

export const APPLICATIONORDEROPTIONS = [
    t('BizCards'),
    t('Calendar'),
    t("Contacts"),
    t('Events'),
    t("Timeclock"),
    t('Members'),
    t('Tasks')];
