
export const LANGUAGEDATA = [
    { name: "English", icon: require('../../../../assets/app-images/Japan.png') },
    { name: "Chinese", icon: require('../../../../assets/app-images/Japan-1.png') },
    { name: "Spanish", icon: require('../../../../assets/app-images/Japan-2.png') },
]