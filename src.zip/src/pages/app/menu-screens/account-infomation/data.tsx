import { t } from "i18next";

export const ACCOUNTSETTINGDATA = [t(`AccountInformation`), t('ChangePassword'), t(`Subscription`), t(`CountryAndLanguage`)]

export const ACCOUNGINFORMATION = [
    { name: t(`AccountType`), val: t(`Business`) },
    { name: t(`PhoneNumber`), val: "+1 (234) 567 8900" },
    { name: t(`Email`), val: "georgelee@gmail.com" },
    { name: t(`Industry`), val: t("Construction") },
    { name: t(`PrimarySpeciality`), val: t(`Generalcontractor`) },
]

export const LOGININFORMATION = [t(`Loginwithpassword`), t('LoginwithTouchID'), t(`LoginwithFaceID`)]