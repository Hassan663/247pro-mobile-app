import { t } from "i18next";

export const OPTIONSDATA = [t(`EditSubscription`), t('CancelSubscription')]