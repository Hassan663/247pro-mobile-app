export const AMOUTDATA = ['$42,334.00', '$42,334.00', '$42,334.00', '$42,334.00']
export const  DATEDATA = ['May 22, 2023', 'May 24, 2023', 'May 25, 2023', 'May 26, 2023']