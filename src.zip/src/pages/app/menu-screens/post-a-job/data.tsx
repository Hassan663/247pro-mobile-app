import { t } from "i18next";

export const JOBTITLE = [
    { isEditable:true,name: t(`InstallAfaucet`) },
    { isEditable:false,name: t('WaterHeater') },
    { isEditable:false,name: t('KitchenSink') },
    { isEditable:false,name: t('Bathroomremodel') },
    { isEditable:false,name: t('Electrical') },
    { isEditable:false,name: t('Recessedlights') },
    { isEditable:false,name: t('Pendantlights') },
]