import { t } from "i18next";

export const data: any = [
    {
        id: '1',
        profilePicture: 'https://via.placeholder.com/150',
        value: 'Lillie-Mai Allen',
    },
    {
        id: '2',
        profilePicture: 'https://via.placeholder.com/150',
        value: 'Emmanuel Goldstein',
    },
    {
        id: '3',
        profilePicture: 'https://via.placeholder.com/150',
        value: 'Winston Smith',
    },
    {
        id: '4',
        profilePicture: 'https://via.placeholder.com/150',
        value: 'William Blazkowicz',
    },
    {
        id: '5',
        profilePicture: 'https://via.placeholder.com/150',
        value: 'Gordon Comstock',
    },
    {
        id: '6',
        profilePicture: 'https://via.placeholder.com/150',
        value: 'Philip Ravelston',
    },
    {
        id: '7',
        profilePicture: 'https://via.placeholder.com/150',
        value: 'Rosemary Waterlow',
    },
    {
        id: '8',
        profilePicture: 'https://via.placeholder.com/150',
        value: 'Julia Comstock',
    },
    {
        id: '9',
        profilePicture: 'https://via.placeholder.com/150',
        value: 'Mihai Maldonado',
    },
    {
        id: '10',
        profilePicture: 'https://via.placeholder.com/150',
        value: 'Murtaza Molina',
    },
    {
        id: '11',
        profilePicture: 'https://via.placeholder.com/150',
        value: 'Peter Petigrew',
    },
];


export const DATA = [
    {
        id: 'bd7acbea-c1b1-46c2-aed5-3ad53abb28ba',
        title: 'First Item',
    },
    {
        id: '3ac68afc-c605-48d3-a4f8-fbd91aa97f63',
        title: 'Second Item',
    },
    {
        id: '58694a0f-3da1-471f-bd96-145571e29d72',
        title: 'Third Item',
    },
    {
        id: '58694a0f-3da1-471f-bd96-145571e29d72',
        title: 'Third Item',
    },
    {
        id: '58694a0f-3da1-471f-bd96-145571e29d72',
        title: 'Third Item',
    },
    {
        id: '58694a0f-3da1-471f-bd96-145571e29d72',
        title: 'Third Item',
    },
];