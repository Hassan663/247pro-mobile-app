import { t } from "i18next";

export const DROPDOWNDATA = [t('Share'), t('View'), t('Edit'), t('Converttoproject'), t('ChangeStatus'), t('Delete')]