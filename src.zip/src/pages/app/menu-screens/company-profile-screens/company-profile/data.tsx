import { t } from "i18next";

export const REVIEWS = [5, 4, 3, 2, 1]
export const MOREOPTIONSDATA = [t('Edit'), t('Share'), t('QRCode')]
export const TABSDATA = [t('Overview'), t('Services'), t('Photos'), t('Reviews')];
export const PHOTOTABSDATA = [t('All'), t('Generalcontractor'), t('Electrician'), t('Painter')];
export const SERVICEDATA = [t('Kitchenremodel'), t('Bathroomremodel'), t('AdditionsKitchenremodel'), t('Painting'), t('Electricalworks'), t('Painting'), t('AdditionsKitchenremodel'), t('Painting'), 'HVAC']