import { t } from "i18next";

export const COUNTRYDATA = ['USA', 'Canada', 'UK', 'UAE'];
export const INSDUSTRYTAGS = ['Construction', 'Marketing',];
export const TABSDATA = [t('Overview'), t('Services'), t('Photos'), t('QRCode')];
export const RADIOBTNDATA = [t(`Residential`), t('Commercial'), t(`ResidentialandCommercial`)];
export const SPECIALITYDATA = [t('Architect'), t(`Flooring`), t(`Generalcontractor`), t(`Painting`), t(`Plumber`), t(`windows`)];
export const SERVICEDATA = [t('Kitchenremodel'), t('Bathroomremodel'), t('AdditionsKitchenremodel'), t('Painting'), t('Electricalworks'), t('Painting'), t('AdditionsKitchenremodel'), t('Painting'), 'HVAC',]
export const PHOTOTABSDATA = [t('All'), t('Generalcontractor'), t('Electrician'), t('Painter'),t('Plumber')];
export const ALLPHOTOSDATA= [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]