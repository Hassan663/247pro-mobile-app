import { t } from "i18next";

export const CONTACTINFOINPUTS = [t('firstname'), t('lastName'), t('Email')]
 