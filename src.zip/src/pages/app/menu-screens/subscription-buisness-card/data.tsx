import { t } from "i18next";

export const SUBSCRIPTIONDATA = [
    {
        isFree: true,
        name: t(`Basic`),
        desc1: t(`Limitedtomathpermonth`),
        desc2: t(`FreelyenjoyourbasicProFinderfeatureslikejobpostingandjobmatches`),
        CurrentSubscription: true,
    },
    {
        isFree: false,
        name: `Priority 5`,
        desc1: t(`Uptomatchespermonth`),
        currentPrice: '$49.00',
        oldPrice: '$99.00',
        savePrice: '$600.00',
        desc2: t(`Forcompaniesthatneedtogrowtheirbusinessbutnotveryhungryfornewbusiness`),
        CurrentSubscription: false,
    },
    {
        isFree: false,
        name: `Priority 5`,
        desc1: t(`Uptomatchespermonth`),
        currentPrice: '$49.00',
        oldPrice: '$99.00',
        savePrice: '$600.00',
        desc2: t(`Forcompaniesthatneedtogrowtheirbusinessbutnotveryhungryfornewbusiness`),
        CurrentSubscription: false,
    },
    {
        isFree: false,
        name: `Priority 5`,
        desc1: t(`Uptomatchespermonth`),
        currentPrice: '$49.00',
        oldPrice: '$99.00',
        savePrice: '$600.00',
        desc2: t(`Forcompaniesthatneedtogrowtheirbusinessbutnotveryhungryfornewbusiness`),
        CurrentSubscription: false,
    },
]